package edu.utep.cs.cs4330.booky;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.firebase.client.Firebase;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class AddBook extends AppCompatActivity {
    EditText edit_book_title;
    EditText edit_book_author;
    EditText edit_book_genre;
    EditText edit_book_isbn;
    Button save;
    Firebase firebase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);

        edit_book_title = findViewById(R.id.edit_book_title);
        edit_book_author = findViewById(R.id.edit_book_author);
        edit_book_genre = findViewById(R.id.edit_book_genre);
        edit_book_isbn = findViewById(R.id.edit_book_isbn);

        save = findViewById(R.id.saveButton);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                String key = database.getReference("Book").push().getKey();

                Book book = new Book();
                book.setTitle(edit_book_title.getText().toString());
                book.setAuthor(edit_book_author.getText().toString());
                book.setGenre(edit_book_genre.getText().toString());
                book.setISBN(edit_book_isbn.getText().toString());

                Map<String, Object> childUpdates = new HashMap<>();
                childUpdates.put(key, book.toFirebaseObject());
                database.getReference("Book").updateChildren(childUpdates, new DatabaseReference.CompletionListener(){
                    @Override
                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference){
                        if (databaseError == null){
                            finish();
                        }
                    }
                });
            }
        });
    }
}